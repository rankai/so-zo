class CreatePublishes < ActiveRecord::Migration
  def change
    create_table :publishes do |t|

      t.string       :name,          null: false
      t.string       :description, 	 null: false
      t.references   :state,         null: false 
      t.references   :user,          null: false
      t.attachement  :publish_image

      t.timestamps
    end

    add_index :publishes, :user_id

    create_table publishes_tags do |t|
      t.belongs_to  :publish
      t.belongs_to  :tag
    end
  end
end
