class CreateOrders < ActiveRecord::Migration
  def change
    create_table :orders do |t|

      t.string       :order_number,  null: false
      t.string       :sum, 			     null: false
      t.references   :state,         null: false 
      t.references   :user,          null: false

      t.timestamps
    end

    add_index :orders, :order_number
    add_index :orders, :user_id
  end
end
