class AddBaseTables < ActiveRecord::Migration
  def change
  	create_table :bases do |t|
  		t.string	:title,  :null => false
  		t.text		:detail, :null => false

  		t.timestamps
  	end

  	create_table :sizes do |t|
  		t.string    :name
  		t.string    :size_value

  		t.timestamps
  	end

  	create_table :colors do |t|
  		t.string    :name
  		t.string    :rgb

  		t.timestamps
  	end
  end
end
