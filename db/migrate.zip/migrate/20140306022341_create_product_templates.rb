class CreateProductTemplates < ActiveRecord::Migration
  def change
    create_table :product_templates do |t|

      t.string     :template_name,                  null: false
      t.text       :description,                    null: false
      t.string     :price,                          null: false
      t.references :template_category,              null: false
      t.integer    :position_X
      t.integer    :position_Y
      t.integer    :size_W
      t.integer    :size_H
      t.integer    :degree
      t.integer    :if_zoom
      t.attachment :head_image
      t.attachment :head_image_mask
      t.attachment :back_image
      t.attachment :back_image_mask
      t.attachment :side_image
      t.attachment :side_image_mask



      t.timestamps
    end

    create_table colors_product_templates do |t|
    	t.belongs_to :color
    	t.belongs_to :product_template
    end

    create_table product_templates_sizes do |t| 
    	t.belongs_to :product_template
      t.belongs_to :size
    end

  end
end