class CreateProducts < ActiveRecord::Migration
  def change
    create_table :products do |t|
      t.string     :name,                       null: false 
      t.text       :description,                null: false
      t.string     :base_price,                 null: false
      t.string     :price,                      null: false
      t.references :state,                      null: false
      t.references :publish,                    null: false
     #t.references :user
      t.references :product_template            null: false
      t.integer    :publish_degree
      t.integer    :publish_pos_X
      t.integer    :publish_pos_Y
      t.integer    :publish_size_W
      t.integer    :publish_size_H


      t.timestamps
    end

    create_table product_images do |t|
    	t.references :product
    	t.attachment :product_image
    end

  end
end
