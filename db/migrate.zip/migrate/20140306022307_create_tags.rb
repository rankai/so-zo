class CreateTags < ActiveRecord::Migration
  def change
    create_table :tags do |t|

      t.string      :tag_name
      t.references  :color
      t.text        :description

      t.timestamps
    end

    create_table :tags_users do |t|
    	t.belongs_to :user
    	t.belongs_to :tag
    end

    create_table :publishes_tags do |t|
    	t.belongs_to :publish
    	t.belongs_to :tag
    end

  end
end
